using Midland.Core.Common;

namespace EmployeeData.Common.Models;

public class UserSelectModelExpanded : UserSelectModel
{
	public string Email { get; set; }
}