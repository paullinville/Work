﻿namespace EmployeeData.Common.Models;

public class ReportModel
{
	public string ReportKey { get; set; }
	public string ReportName { get; set; }
}