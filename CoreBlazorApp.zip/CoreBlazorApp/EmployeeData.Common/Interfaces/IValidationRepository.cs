﻿using Midland.Core.Validation;

namespace EmployeeData.Common.Interfaces;

public interface IValidationRepository : IValidationData
{
}