﻿namespace EmployeeData.Common.Interfaces;

public partial interface IEmployeeDataRepository
{
}