﻿namespace EmployeeData.Common;

public class Setting
{
	public string Name { get; set; }
	public object Value { get; set; }
}