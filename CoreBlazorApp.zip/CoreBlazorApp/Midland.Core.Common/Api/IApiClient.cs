﻿namespace Midland.Core.Api;

/// <summary>
/// Interface required for all Midland API interfaces that use the Api Discovery and Token Http
/// Client Handlers
/// </summary>
public interface IApiClient
{
}