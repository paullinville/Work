﻿namespace Midland.Core.Validation
{
	public enum ValidationSeverity
	{
		Critical = 100,
		Information = 300
	}
}