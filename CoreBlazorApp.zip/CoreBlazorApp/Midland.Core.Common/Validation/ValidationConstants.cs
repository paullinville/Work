﻿namespace Midland.Core.Validation;

public class ValidationConstants
{
	public const string ErrorKeyPart = "{A3871C1A-BA6D-48D2-87D1-084329CD7464}";
}