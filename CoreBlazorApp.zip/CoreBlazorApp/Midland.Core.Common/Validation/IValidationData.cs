﻿namespace Midland.Core.Validation
{
	public interface IValidationData
	{
	}
}