﻿namespace Midland.Core.Api;

public class VaultTokenSecret
{
	public VaultTokenData Data { get; set; }
	public VaultSecretMetaData MetaData { get; set; }
}