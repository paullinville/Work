﻿namespace Midland.Core.ApplicationSecurity;

public interface IMidlandRoleAction
{
	int ActionRef { get; }
	int RoleRef { get; }
}