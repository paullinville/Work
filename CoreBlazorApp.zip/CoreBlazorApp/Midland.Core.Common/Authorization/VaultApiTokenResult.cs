﻿namespace Midland.Core.Api;

public class VaultApiTokenResult : VaultResult<VaultTokenSecret>
{ }