﻿namespace Midland.Core.Api;

public class VaultTokenData
{
	public string Token { get; set; }
}