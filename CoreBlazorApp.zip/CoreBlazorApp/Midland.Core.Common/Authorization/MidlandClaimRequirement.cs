﻿namespace Midland.Core.Authorization;

public class MidlandClaimRequirement
{
    public string ClaimDescription { get; set; }
    public string Name { get; set; }
}