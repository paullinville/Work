﻿namespace Midland.Core.Common;

public class TokenSecuritySettings
{
	public const string VaultSource = "Vault";
	public string Source { get; set; }
}