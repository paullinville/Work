﻿namespace Midland.Core.Common;

public class HealthModelVersion
{
	public string AssemblyName { get; set; }
	public string Version { get; set; }
}