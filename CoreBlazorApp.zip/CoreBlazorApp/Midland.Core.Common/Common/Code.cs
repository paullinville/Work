﻿namespace Midland.Core.Common;

public interface ICode
{
	int CodeRef { get; set; }

	string Name { get; set; }
}