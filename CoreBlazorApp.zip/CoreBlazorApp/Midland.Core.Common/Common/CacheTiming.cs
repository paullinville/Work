﻿namespace Midland.Core.Common;

public class CacheTiming
{
	public int UserMinutes { get; set; }
	public int ApplicationSecurityMinutes { get; set; }
}