﻿namespace Midland.Core.Common;

public sealed class ErrorType
{
	public static string Field { get => "field"; }
	public static string General { get => "general"; }
	public static string Eatts { get => "eatts"; }
}