﻿namespace Midland.Core.SimpleMessageBus;

public interface IPublisher
{
}