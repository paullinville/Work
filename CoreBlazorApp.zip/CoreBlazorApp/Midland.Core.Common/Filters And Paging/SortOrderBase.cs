﻿namespace Midland.Core.Common;

public class SortOrder
{
    public bool? Asc { get; set; } = true;

    public int? Order { get; set; }
}