﻿namespace Midland.Core.Common;

public sealed class CriteriaFunctions
{
    /// <summary>
    /// Only applicable to string
    /// </summary>
    public const string Contains = "Contains";

    /// <summary>
    /// Only applicable to string
    /// </summary>
    public const string EndsWith = "EndsWith";

    /// <summary> Only applicable to List<T> </summary>
    public const string In = "IN";

    /// <summary> Only applicable to List<T> </summary>
    public const string NOT_IN = "NOT IN";

    /// <summary>
    /// Only applicable to string
    /// </summary>
    public const string StartsWith = "StartsWith";
}