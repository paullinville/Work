﻿namespace Midland.Core.Common;

public class Include
{
    public string Field { get; set; }
    public List<int> Values { get; set; }
}