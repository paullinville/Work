﻿namespace Midland.Core.Common;

[AttributeUsage(AttributeTargets.Property)]
public class SortAndFilterIgnoreAttribute : Attribute
{

}