﻿namespace SecurityModel.Common;

public sealed class SecurityModelConstants
{
	public const string AdminGroup = "Admin";
	public const string ApplicationSlug = "applicationSlug";
	public const long MaxLifetimeSeconds = 315569520;
	public const string Token_User_Ref_Claim = "responsibleUserRef";
}