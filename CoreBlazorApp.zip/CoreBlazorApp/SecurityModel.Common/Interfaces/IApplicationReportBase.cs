﻿namespace SecurityModel.Common.Interfaces;

public interface IApplicationReportBase
{
	int ApplicationRef { get; set; }
}