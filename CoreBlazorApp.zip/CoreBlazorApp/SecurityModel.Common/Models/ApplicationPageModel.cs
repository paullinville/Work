﻿namespace SecurityModel.Common.Models;

public class ApplicationPageModel : PageRequestModel
{
	public string Name { get; set; }
}