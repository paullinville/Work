﻿namespace SecurityModel.Common.Models;

public class ApiDisableModel
{
	public string Name { get; set; }
}