using System.Collections.Generic;

namespace SecurityModel.Common.Models;

public class ApiActionsUsersCriteriaModel
{
    public List<string> Actions { get; set; }
}