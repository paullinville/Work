﻿namespace SecurityModel.Common.Models;

public class ServiceTokenModel
{
	public string Token { get; set; }
}