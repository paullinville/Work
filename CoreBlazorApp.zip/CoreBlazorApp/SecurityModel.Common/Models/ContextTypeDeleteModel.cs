﻿namespace SecurityModel.Common.Models;

public class ContextTypeDeleteModel
{
	public int ContextTypeRef { get; set; }
}
