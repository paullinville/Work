﻿namespace SecurityModel.Common.Models;

public class ApplicationUserReportCriteria : ApplicationReportBase
{
}