﻿namespace SecurityModel.Common.Models;

public class ApplicationRoleReportCriteria : ApplicationReportBase
{
}