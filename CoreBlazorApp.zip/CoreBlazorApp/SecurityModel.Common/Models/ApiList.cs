﻿using System.Collections.Generic;

namespace SecurityModel.Common.Models;

public class ApiList
{
	public List<string> Keys { get; set; }
}