using System.Collections.Generic;

namespace SecurityModel.Common.Models;

public class ApiActionsUsersCriteria
{
    public List<string> Actions { get; set; }
}