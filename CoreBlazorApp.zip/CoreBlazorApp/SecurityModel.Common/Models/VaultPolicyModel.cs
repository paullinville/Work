﻿namespace SecurityModel.Common.Models;

public class VaultPolicyModel
{
    public string Policy { get; set; }
}