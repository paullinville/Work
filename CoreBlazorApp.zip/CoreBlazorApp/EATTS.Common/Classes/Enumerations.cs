﻿namespace EATTS.Common.Classes;

public class Enumerations
{
	public enum ApplicationParameters
	{
		ApiLogsLocation = 1,
		ArchiveApiLogs = 2,
		SkipApiLoging = 3
	}
}