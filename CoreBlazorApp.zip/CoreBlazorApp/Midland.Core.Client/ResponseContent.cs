﻿using Midland.Core.Common;

namespace Midland.Core.Client;

public class ResponseContent : ResponseContentBase
{
	public object Content { get; set; }
}